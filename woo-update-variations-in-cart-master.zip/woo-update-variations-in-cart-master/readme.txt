=== Plugin Name ===
Contributors: codingkart
Donate link: http://www.codingkart.com/donate/
Tags: woocommerce update variation on cart, woocommerce cart, woocommerce variation, woocommerce change variation, woocommerce
Requires at least: 4.7
Tested up to: 4.7
Stable tag: 4.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Easily update product variation on cart page with ajax, So customers don't need to remove and add product again.

== Description ==

Easily update product variation on cart page with ajax, So customers don't need to remove and add product again. 

Note: This plugin require WooCommerce. It will only work with standard woocommerce variable products.

live demo : http://ganesh.codingkloud.com/

== Installation ==

Just download the plugin and enjoy!!!

e.g.

1. Upload the plugin files to the '/wp-content/plugins/plugin-name' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Cart Variation Update screen to configure the plugin



== Frequently Asked Questions ==

= Does this plugin works with custom variations? =

No it only works with woocommerce standard variations.

= Can I change the edit link text on cart page? =

Yes you can navigate to setting page of plugin and update.

== Screenshots ==

1. setting.
2. cart page
3. clicked on edit link
4. updated product

== Changelog ==

= 0.0.2 =

-Fixed Issue,Now Multisite Network Supported.

= 0.0.1 =



== Upgrade Notice ==

= 0.0.1 =
Dirctly works after activation.

= 0.0.2 =
Fixed Issue,Now Multisite Network Supported.
